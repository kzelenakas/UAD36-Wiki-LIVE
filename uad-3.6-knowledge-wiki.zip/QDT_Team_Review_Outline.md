# True Footage UAD 3.6 Knowledge Wiki
## Quality & Development Team (QDT) Review & Input Outline

**Document Purpose:** Presentation and review outline for the Quality & Development Team (QDT) to evaluate the UAD 3.6 Knowledge Wiki content structure, FAQ taxonomy, Google Drive sync organization, and AI grounding parameters.

---

### 1. Executive Summary & Core Objective

The **True Footage UAD 3.6 Knowledge Wiki** serves as the central interactive reference hub and AI Q&A assistant for True Footage staff appraisers navigating Fannie Mae & Freddie Mac's UAD 3.6 standards transition.

**Primary Goals for QDT Input:**
- Review and refine the 8 core Knowledge Wiki sections.
- Validate the baseline FAQ categories and submit high-priority appraiser questions.
- Confirm Google Drive subfolder alignment for automated resource tagging.
- Establish QDT review protocols for incoming appraiser questions submitted through the tool.

---

### 2. Knowledge Wiki Sections (Core Modules)

The tool organizes knowledge and reference documents into 8 primary UAD 3.6 domain modules:

1. **UAD 3.6 General Overview**
   * *Scope:* Transition timelines, joint GSE standards, UAD 2.6 vs 3.6 structural differences, and mandate compliance rules.
   * *Target Docs:* GSE Announcements, High-Level Transition Timelines, Standard Fact Sheets.

2. **Subject Property Characteristics**
   * *Scope:* Expanded itemized property inputs, kitchen and bathroom updates, architectural attributes, and physical component data.
   * *Target Docs:* Field Collection Checklists, Kitchen/Bath Update Matrices, Dwelling Data Guides.

3. **Sales Comparison Approach & Grid**
   * *Scope:* Expanded grid fields, matched-pair analysis standards, quantitative vs qualitative adjustment criteria, and comparable selection.
   * *Target Docs:* Sales Comparison Field Guides, Grid Mapping Charts, GSE Valuation Rules.

4. **Data Entry & Appraisal Tools**
   * *Scope:* Software integrations (aCI, TOTAL, ClickFORMS, Bradford), partial remodeling inputs, and data validation rules.
   * *Target Docs:* Software Setup Manuals, Export/Import Guides, Vendor Compatibility Notes.

5. **Building Materials & Condition Ratings**
   * *Scope:* Calibrated C1 through C6 condition rating definitions, physical wear benchmarks, deferred maintenance, and photo requirements.
   * *Target Docs:* C1-C6 Rating Calibration Manuals, Defect Classification Standards, Photo Exhibits.

6. **Quality Ratings & Structural Exhibits**
   * *Scope:* Q1 through Q6 quality rating calibration, custom vs tract finish differentiation, structural framework, and material grade exhibits.
   * *Target Docs:* Q1-Q6 Quality Spec Sheets, High-End vs Standard Finish Photographic Guides.

7. **Location & View Adjustments**
   * *Scope:* Dual-factor coding (Influence + Location Type), proximity to transit/waterfront/commercial, and view rating consistency.
   * *Target Docs:* Location Rating Matrix, View Influence Decision Trees, Site Adjustment Guides.

8. **Form Layouts & Uniform Reporting**
   * *Scope:* Dynamic form layout transitions, field coordinate mapping, GSE uniform reporting standards, and compliance validation.
   * *Target Docs:* UAD 3.6 Field Coordinate Maps, Uniform Appraisal Dataset Specifications, QA Validation Checklists.

---

### 3. Wiki FAQ Categories & Sample Appraiser Questions

| FAQ Category | Description | Sample Question for QDT Validation |
| :--- | :--- | :--- |
| **UAD 3.6 General Overview** | Mandates, GSE rules, transition timelines | *"What are the key operational differences between UAD 2.6 and UAD 3.6?"* |
| **Data Entry into Appraisal Tools** | Form software, field codes, partial updates | *"How do we code a partially updated kitchen with original cabinetry but new granite counters?"* |
| **Condition & Quality Rating Standards**| C1-C6 & Q1-Q6 calibration, deferred maintenance | *"Can a home with C3 condition receive a Q2 quality rating if high-end materials were used?"* |
| **Location & View Adjustments** | Proximity factors, site influences, dual coding | *"How should we code a property backing onto a municipal rail line with dense tree screening?"* |
| **Client & GSE Overrides** | Lender-specific overlay rules vs GSE baseline | *"What takes priority if a lender overlay conflicts with Fannie Mae UAD 3.6 guidance?"* |

---

### 4. Proposed Google Drive Folder Structure Alignment

To ensure automatic document ingestion and section tagging, Google Drive resources should be organized into the following subfolders:

```text
📁 True Footage UAD 3.6 Knowledge Base (Google Drive Root)
 ├── 📁 01_General_Overview
 ├── 📁 02_Subject_Characteristics
 ├── 📁 03_Sales_Comparison
 ├── 📁 04_Appraisal_Tools
 ├── 📁 05_Condition_Ratings
 ├── 📁 06_Quality_Ratings
 ├── 📁 07_Location_View
 └── 📁 08_Form_Layouts
```

*Supported Sync Formats:* Google Docs, Google Sheets, Google Slides, PDFs, MP4 Videos, JPEG/PNG Images, and Drive Shortcut Links.

---

### 5. Platform Features & Capabilities Overview

1. **Google NotebookLM AI Grounding:**
   - Appraisers ask questions in natural language.
   - AI responses are strictly grounded in the official True Footage reference documents for the selected Wiki section.
   - Includes direct citations and source document links.

2. **Automated Google Drive Sync:**
   - Webhook-enabled background sync automatically updates the Wiki whenever new documents or revisions are added to Drive.

3. **In-App Document Viewer & Multi-User Annotations:**
   - Appraisers can view PDFs, Docs, Sheets, Slides, and Videos directly in the app.
   - Supports team highlight annotations and sticky notes for collective knowledge building.

4. **Interactive Question Submission Queue:**
   - If an appraiser cannot find an answer, they can submit a question directly to the QDT team.
   - QDT administrators can review, answer, and convert answered questions into published FAQs.

5. **QDT Admin Console:**
   - Admin management for reordering sections, toggling resource visibility, monitoring sync logs, and managing team permissions (@truefootage.tech).

---

### 6. Action Items & Input Requested from QDT

Please review this document and provide feedback on the following:

- [ ] **Section Scope:** Are the 8 Knowledge Wiki sections sufficient, or should additional modules be created (e.g. *Desktop & Hybrid Appraisals*)?
- [ ] **Priority FAQs:** What are the top 10 questions appraisers are currently asking QDT regarding UAD 3.6?
- [ ] **Drive Folder Structure:** Confirm agreement with the proposed 8 subfolders in Google Drive.
- [ ] **QDT Queue Reviewers:** Identify which QDT team members will be assigned to manage and publish answers to incoming appraiser inquiries.

---
*Generated for True Footage Quality & Development Team Review*
