import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { db } from "./server/db.js"; // note: we can import directly or through path since tsx resolves types

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini Client safely
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("Gemini Client initialized successfully for NotebookLM Q&A Proxy.");
  } catch (error) {
    console.error("Failed to initialize Gemini API Client:", error);
  }
} else {
  console.log("No GEMINI_API_KEY environment variable found. Q&A will run in rich simulated mode.");
}

// -------------------------------------------------------------
// API ROUTES FIRST
// -------------------------------------------------------------

// Auth simulator
app.post("/api/auth/login", (req, res) => {
  const { email, displayName } = req.body;
  if (!email || !email.includes("@")) {
    return res.status(400).json({ error: "A valid email address is required" });
  }

  const allowedDomain = process.env.ALLOWED_DOMAIN || "truefootage.tech";
  const domain = email.split("@")[1];

  if (domain.toLowerCase() !== allowedDomain.toLowerCase() && !email.endsWith("admin@truefootage.tech") && !email.endsWith("kevin.zelenakas@truefootage.tech")) {
    return res.status(403).json({
      error: `Access Denied: Logins are restricted to verified accounts on the Google Workspace domain '@${allowedDomain}'.`
    });
  }

  // Set roles. Custom provision for specific users
  const isAdmin = email.includes("admin") || email.includes("kevin.zelenakas");
  const userProfile = {
    uid: `usr-${Date.now()}`,
    email,
    displayName: displayName || email.split("@")[0],
    role: isAdmin ? "admin" : "staff",
    domain
  };

  res.json({ user: userProfile });
});

// Resources
app.get("/api/resources", (req, res) => {
  res.json({ resources: db.getResources() });
});

app.post("/api/resources", (req, res) => {
  const { title, resourceType, moduleTags, description, driveFileId, webViewLink, size, actorEmail } = req.body;
  if (!title || !resourceType || !moduleTags || !moduleTags.length) {
    return res.status(400).json({ error: "Missing required resource properties (title, resourceType, moduleTags)" });
  }

  const newResource = db.createResource({
    driveFileId: driveFileId || `drive-res-${Date.now()}`,
    title,
    resourceType,
    moduleTags,
    description,
    lastSyncedRevisionId: `rev-${Math.floor(Math.random() * 9000 + 1000)}`,
    driveLastModified: new Date().toISOString(),
    publishStatus: "published",
    webViewLink: webViewLink || "https://docs.google.com/document/d/1_Preview/edit",
    size: size || "100 KB"
  }, actorEmail || "admin@truefootage.tech");

  res.status(201).json({ resource: newResource });
});

app.put("/api/resources/:id", (req, res) => {
  const { id } = req.params;
  const { title, resourceType, moduleTags, description, publishStatus, webViewLink, size, actorEmail } = req.body;
  
  try {
    const updated = db.updateResource(id, {
      ...(title && { title }),
      ...(resourceType && { resourceType }),
      ...(moduleTags && { moduleTags }),
      ...(description !== undefined && { description }),
      ...(publishStatus && { publishStatus }),
      ...(webViewLink && { webViewLink }),
      ...(size && { size }),
      driveLastModified: new Date().toISOString()
    }, actorEmail || "admin@truefootage.tech");
    res.json({ resource: updated });
  } catch (error: any) {
    res.status(404).json({ error: error.message });
  }
});

app.delete("/api/resources/:id", (req, res) => {
  const { id } = req.params;
  const { actorEmail } = req.body;
  try {
    db.deleteResource(id, actorEmail || "admin@truefootage.tech");
    res.json({ success: true });
  } catch (error: any) {
    res.status(404).json({ error: error.message });
  }
});

// FAQ Sections
app.get("/api/faq/sections", (req, res) => {
  res.json({ sections: db.getFaqSections() });
});

app.post("/api/faq/sections", (req, res) => {
  const { name, actorEmail } = req.body;
  if (!name) return res.status(400).json({ error: "Section name is required" });
  const section = db.createFaqSection(name, actorEmail || "admin@truefootage.tech");
  res.status(201).json({ section });
});

app.put("/api/faq/sections/reorder", (req, res) => {
  const { orders, actorEmail } = req.body; // Array of { id, order }
  if (!orders || !Array.isArray(orders)) return res.status(400).json({ error: "Orders array is required" });
  const sections = db.updateFaqSectionOrder(orders, actorEmail || "admin@truefootage.tech");
  res.json({ sections });
});

app.put("/api/faq/sections/:id", (req, res) => {
  const { id } = req.params;
  const { name, actorEmail } = req.body;
  if (!name) return res.status(400).json({ error: "Section name is required" });
  try {
    const section = db.updateFaqSection(id, name, actorEmail || "admin@truefootage.tech");
    res.json({ section });
  } catch (error: any) {
    res.status(404).json({ error: error.message });
  }
});

app.delete("/api/faq/sections/:id", (req, res) => {
  const { id } = req.params;
  const { actorEmail } = req.body;
  try {
    db.deleteFaqSection(id, actorEmail || "admin@truefootage.tech");
    res.json({ success: true });
  } catch (error: any) {
    res.status(404).json({ error: error.message });
  }
});

// FAQ Entries
app.get("/api/faq/entries", (req, res) => {
  res.json({ entries: db.getFaqEntries() });
});

app.post("/api/faq/entries", (req, res) => {
  const { sectionId, question, answer, status, moduleTags, actorEmail } = req.body;
  if (!sectionId || !question || !answer) {
    return res.status(400).json({ error: "Missing required properties (sectionId, question, answer)" });
  }
  const entry = db.createFaqEntry({
    sectionId,
    question,
    answer,
    status: status || "draft",
    moduleTags: moduleTags || []
  }, actorEmail || "admin@truefootage.tech");
  res.status(201).json({ entry });
});

app.put("/api/faq/entries/:id", (req, res) => {
  const { id } = req.params;
  const { sectionId, question, answer, status, moduleTags, actorEmail, note } = req.body;
  try {
    const updated = db.updateFaqEntry(id, {
      ...(sectionId && { sectionId }),
      ...(question && { question }),
      ...(answer && { answer }),
      ...(status && { status }),
      ...(moduleTags && { moduleTags })
    }, actorEmail || "admin@truefootage.tech", note);
    res.json({ entry: updated });
  } catch (error: any) {
    res.status(404).json({ error: error.message });
  }
});

app.delete("/api/faq/entries/:id", (req, res) => {
  const { id } = req.params;
  const { actorEmail } = req.body;
  try {
    db.deleteFaqEntry(id, actorEmail || "admin@truefootage.tech");
    res.json({ success: true });
  } catch (error: any) {
    res.status(404).json({ error: error.message });
  }
});

// Submitted Questions Queue
app.get("/api/submitted-questions", (req, res) => {
  res.json({ questions: db.getSubmittedQuestions() });
});

app.post("/api/submitted-questions", (req, res) => {
  const { question, userId, userEmail, userName, categoryName } = req.body;
  if (!question || !userEmail) {
    return res.status(400).json({ error: "Question text and user email are required" });
  }
  const newQ = db.createSubmittedQuestion(question, userId || `usr-${Date.now()}`, userEmail, userName || "Staff Appraiser", categoryName);
  res.status(201).json({ question: newQ });
});

app.put("/api/submitted-questions/:id/respond", (req, res) => {
  const { id } = req.params;
  const { adminResponse, actorEmail } = req.body;
  if (!adminResponse) return res.status(400).json({ error: "Admin response is required" });
  try {
    const updated = db.respondToSubmittedQuestion(id, adminResponse, actorEmail || "admin@truefootage.tech");
    res.json({ question: updated });
  } catch (error: any) {
    res.status(404).json({ error: error.message });
  }
});

app.put("/api/submitted-questions/:id/promote", (req, res) => {
  const { id } = req.params;
  const { sectionId, actorEmail } = req.body;
  if (!sectionId) return res.status(400).json({ error: "FAQ section ID is required to promote" });
  
  try {
    const submitted = db.getSubmittedQuestions().find(q => q.id === id);
    if (!submitted) return res.status(404).json({ error: "Submitted question not found" });

    // 1. Create FAQ Entry
    const faq = db.createFaqEntry({
      sectionId,
      question: submitted.question,
      answer: submitted.adminResponse || "This question is currently under review by our Quality team.",
      status: "draft",
      moduleTags: []
    }, actorEmail || "admin@truefootage.tech");

    // 2. Mark Question as Promoted
    const updated = db.promoteToFaq(id, sectionId, faq.id, actorEmail || "admin@truefootage.tech");
    res.json({ question: updated, faq });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Annotations
app.get("/api/annotations", (req, res) => {
  const { resourceId } = req.query;
  res.json({ annotations: db.getAnnotations(resourceId as string) });
});

app.post("/api/annotations", (req, res) => {
  const { resourceId, text, userId, userEmail, userName } = req.body;
  if (!resourceId || !text || !userEmail) {
    return res.status(400).json({ error: "Missing required annotation fields" });
  }
  const annotation = db.addAnnotation(resourceId, text, userId || `usr-${Date.now()}`, userEmail, userName || "Staff Appraiser");
  res.status(201).json({ annotation });
});

app.delete("/api/annotations/:id", (req, res) => {
  const { id } = req.params;
  const { userEmail, isAdmin } = req.body;
  if (!userEmail) return res.status(400).json({ error: "User email is required to delete annotation" });
  try {
    db.deleteAnnotation(id, userEmail, !!isAdmin);
    res.json({ success: true });
  } catch (error: any) {
    res.status(403).json({ error: error.message });
  }
});

// System Config Endpoints
app.get("/api/config", (req, res) => {
  res.json({ config: db.getConfig() });
});

app.put("/api/config", (req, res) => {
  const { driveFolderId, driveFolderName, notebookLmUrl, actorEmail } = req.body;
  if (!driveFolderId || !driveFolderName || !notebookLmUrl) {
    return res.status(400).json({ error: "Missing config parameters" });
  }
  const config = db.updateConfig({ driveFolderId, driveFolderName, notebookLmUrl }, actorEmail || "admin@truefootage.tech");
  res.json({ config });
});

// Dynamic Wiki Sections Endpoints
app.get("/api/curriculum/modules", (req, res) => {
  res.json({ modules: db.getModules() });
});

app.post("/api/curriculum/modules", (req, res) => {
  const { name, description, actorEmail } = req.body;
  if (!name || !name.trim()) {
    return res.status(400).json({ error: "Section name is required" });
  }
  try {
    const modules = db.createModule(name.trim(), description?.trim() || '', actorEmail || "admin@truefootage.tech");
    res.status(201).json({ modules });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.put("/api/curriculum/modules/reorder", (req, res) => {
  const { modules, actorEmail } = req.body;
  if (!modules || !Array.isArray(modules)) {
    return res.status(400).json({ error: "Modules list array is required" });
  }
  const updated = db.reorderModules(modules, actorEmail || "admin@truefootage.tech");
  res.json({ modules: updated });
});

app.put("/api/curriculum/modules/rename", (req, res) => {
  const { oldName, newName, description, actorEmail } = req.body;
  if (!oldName) {
    return res.status(400).json({ error: "Old section name is required" });
  }
  const nameToUse = (newName && newName.trim()) ? newName.trim() : oldName;
  try {
    const updated = db.updateModule(oldName, nameToUse, description, actorEmail || "admin@truefootage.tech");
    res.json({ modules: updated });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.delete("/api/curriculum/modules", (req, res) => {
  const { name, actorEmail } = req.body;
  if (!name) {
    return res.status(400).json({ error: "Section name is required to delete" });
  }
  try {
    const updated = db.deleteModule(name, actorEmail || "admin@truefootage.tech");
    res.json({ modules: updated });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Resources Reordering Endpoints
app.put("/api/resources/reorder", (req, res) => {
  const { orders, actorEmail } = req.body; // Array of { id, order }
  if (!orders || !Array.isArray(orders)) {
    return res.status(400).json({ error: "Orders array is required" });
  }
  const resources = db.updateResourcesOrder(orders, actorEmail || "admin@truefootage.tech");
  res.json({ resources });
});

// Audit Logs
app.get("/api/audit-logs", (req, res) => {
  res.json({ logs: db.getAuditLogs() });
});

// Simulated Drive Changes API Webhook
// Admins can trigger this endpoint in-app to test how files uploaded directly to
// Google Drive folders dynamically propagate to Firestore without manual refreshes!
app.post("/api/sync/drive-trigger", (req, res) => {
  const { action, title, fileType, moduleTag, actorEmail } = req.body;
  
  if (!action || !title) {
    return res.status(400).json({ error: "Action and file title are required for simulated webhook" });
  }

  const email = actorEmail || "drive-changes-api@system.gserviceaccount.com";

  if (action === "create" || action === "update") {
    const matchedType = fileType || "doc";
    const tags = moduleTag ? [moduleTag] : ["UAD 3.6 General Overview"];
    const ext = matchedType === "doc" ? "docx" : matchedType === "sheet" ? "xlsx" : matchedType === "slide" ? "pptx" : "pdf";
    const driveId = `drive-hook-${Math.floor(Math.random() * 900000 + 100000)}`;

    const existing = db.getResources().find(r => r.title.toLowerCase() === title.toLowerCase());

    if (existing) {
      const updated = db.updateResource(existing.id, {
        driveLastModified: new Date().toISOString(),
        lastSyncedRevisionId: `rev-hook-${Math.floor(Math.random() * 900 + 100)}`
      }, email);
      res.json({
        message: `Webhook received: Google Drive updated existing file '${title}'.`,
        resource: updated
      });
    } else {
      const created = db.createResource({
        driveFileId: driveId,
        title: `${title}.${ext}`,
        resourceType: matchedType,
        moduleTags: tags,
        description: `This file was pushed directly into Google Drive. The Drive Changes API webhook immediately detected the file addition and registered this record.`,
        lastSyncedRevisionId: "rev-hook-100",
        driveLastModified: new Date().toISOString(),
        publishStatus: "published",
        webViewLink: `https://docs.google.com/document/d/${driveId}_Preview/edit`,
        size: "240 KB"
      }, email);
      res.json({
        message: `Webhook received: Google Drive detected new file '${title}.${ext}'. Indexing complete.`,
        resource: created
      });
    }
  } else if (action === "delete") {
    const existing = db.getResources().find(r => r.title.toLowerCase().startsWith(title.toLowerCase()));
    if (!existing) {
      return res.status(404).json({ error: `File starting with '${title}' not found in resources to delete` });
    }
    db.deleteResource(existing.id, email);
    res.json({
      message: `Webhook received: Google Drive detected file '${existing.title}' was deleted. De-indexing complete.`
    });
  } else {
    res.status(400).json({ error: "Invalid webhook action (must be 'create', 'update', or 'delete')" });
  }
});

// NotebookLM Q&A Proxy Endpoint
// Queries Gemini with NotebookLM master knowledge base first, then optionally correlates with targeted section docs!
app.post("/api/notebooklm/query", async (req, res) => {
  const { moduleId, question, chatHistory, includeSectionDocs = true, activeSources } = req.body;

  if (!question) {
    return res.status(400).json({ error: "Question is required" });
  }

  // 1. Gather section resources & FAQs if section correlation is requested
  const sectionResources = (includeSectionDocs && moduleId)
    ? db.getResources().filter(r => r.moduleTags.includes(moduleId))
    : [];
  const relatedFaqs = (includeSectionDocs && moduleId)
    ? db.getFaqEntries().filter(f => f.status === "published" && f.moduleTags.some(t => moduleId === t))
    : [];

  // Build document contexts for Grounding Injection
  let contextText = `You are the UAD 3.6 TFAN (True Footage Appraisal Notebook) AI Assistant.
PRIMARY KNOWLEDGE SOURCES (NotebookLM Master Vault):
- Fannie Mae & Freddie Mac UAD 3.6 specifications, Appendices, and Field Layouts.
- USPAP (Uniform Standards of Professional Appraisal Practice) 2024-2025 Edition.
- Standard Real Estate Appraisal Textbooks, Valuation Principles, and FHFA Compliance Bulletins.
`;

  if (activeSources && Array.isArray(activeSources) && activeSources.length > 0) {
    contextText += `\nACTIVE SELECTED TFAN MASTER SOURCES (${activeSources.length} sources enabled):\n`;
    activeSources.slice(0, 15).forEach((src, idx) => {
      contextText += `• ${src}\n`;
    });
    if (activeSources.length > 15) {
      contextText += `• ... and ${activeSources.length - 15} additional active TFAN sources.\n`;
    }
  }

  if (includeSectionDocs && moduleId) {
    contextText += `\nADDITIONAL SECTION CONTEXT (Targeted Wiki Section Documents for "${moduleId}"):\n`;
    if (sectionResources.length > 0) {
      sectionResources.forEach((r, idx) => {
        contextText += `[Section Doc #${idx + 1}] ID: ${r.id} | Title: ${r.title} | Type: ${r.resourceType} | Description: ${r.description || "N/A"}\n`;
      });
    } else {
      contextText += `(No specific local documents uploaded for section "${moduleId}" yet. Relying on Master NotebookLM knowledge base).\n`;
    }

    if (relatedFaqs.length > 0) {
      contextText += `\nTargeted Section FAQs:\n`;
      relatedFaqs.forEach((f, idx) => {
        contextText += `FAQ #${idx + 1}: Q: ${f.question} | A: ${f.answer}\n`;
      });
    }

    contextText += `
RESPONSE GUIDELINES:
1. Reference official NotebookLM sources (GSE UAD 3.6 specs, USPAP standards, appraisal textbooks) for definitions, guidelines, and rules.
2. Correlate the response directly with the active wiki section ("${moduleId}") and its specific documents listed above.
3. Provide a structured, authoritative, and helpful answer for a professional real estate appraiser.
4. Include citations linking back to referenced sources.
`;
  } else {
    contextText += `
RESPONSE GUIDELINES:
1. Ground your response in official NotebookLM sources (GSE UAD 3.6 specs, USPAP 2024-2025, and appraisal textbooks).
2. Do not restrict your answer to any single local section document. Provide a comprehensive appraisal standard answer.
3. Keep the tone professional, objective, and clear.
`;
  }

  // Try to use Gemini client
  if (ai) {
    try {
      const messages = [];
      if (chatHistory && Array.isArray(chatHistory)) {
        chatHistory.forEach(msg => {
          messages.push({
            role: msg.role === "user" ? "user" : "model",
            parts: [{ text: msg.content }]
          });
        });
      }
      
      messages.push({
        role: "user",
        parts: [{ text: `${contextText}\n\nUser Question: ${question}` }]
      });

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: messages,
        config: {
          temperature: 0.2, // Low temperature for high precision grounding
        }
      });

      const answerText = response.text || "No response generated by the model.";

      // Extract citations dynamically
      const citations: any[] = [
        {
          resourceId: "notebooklm-master",
          title: "NotebookLM Master Vault (GSE / USPAP / Textbooks)",
          isMaster: true
        }
      ];

      sectionResources.forEach(r => {
        if (answerText.toLowerCase().includes(r.title.toLowerCase()) || answerText.includes(r.id)) {
          citations.push({
            resourceId: r.id,
            title: r.title,
            isMaster: false
          });
        }
      });

      return res.json({
        answer: answerText,
        citations
      });

    } catch (apiError: any) {
      console.error("Gemini API calling error:", apiError);
      return res.status(500).json({
        error: "Internal AI processing error",
        details: apiError.message
      });
    }
  } else {
    // Elegant fallback simulation if GEMINI_API_KEY is not defined yet
    setTimeout(() => {
      const mainCitation = {
        resourceId: "notebooklm-master",
        title: "NotebookLM Master Vault (GSE / USPAP / Textbooks)",
        isMaster: true
      };

      const citationsList = [mainCitation];
      let correlatedNote = "";

      if (includeSectionDocs && sectionResources.length > 0) {
        const doc = sectionResources[0];
        citationsList.push({
          resourceId: doc.id,
          title: doc.title,
          isMaster: false
        });
        correlatedNote = `\n\n*Correlated Section Reference:* **${doc.title}** (${moduleId} Wiki)`;
      }

      const simulatedAnswer = `**[TFAN AI Q&A - NotebookLM Grounded Response]**

Based on the **NotebookLM Master Vault** (Fannie Mae/Freddie Mac GSE UAD 3.6 Specs, USPAP 2024-2025, and Valuation Textbooks):
1. **Core Specification**: Under standard UAD 3.6 requirements, fields require discrete, structured field entries rather than free-form commentary.
2. **USPAP & GSE Alignment**: Compliance mandates verifying subject and comparable ratings against standard Fannie Mae/Freddie Mac definitions and USPAP Standards 1 & 2.
3. **Application**: For questions regarding "${moduleId || 'General UAD 3.6'}", ensure all rating inputs conform to official GSE appendix guidelines.${correlatedNote}

*To activate live Gemini AI generation, add your GEMINI_API_KEY in Settings > Secrets.*`;

      res.json({
        answer: simulatedAnswer,
        citations: citationsList
      });
    }, 600);
  }
});

// -------------------------------------------------------------
// VITE OR STATIC FILE HANDLER MIDDLEWARE
// -------------------------------------------------------------
async function bootstrap() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite development middleware integrated.");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Production static file delivery configured.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`UAD 3.6 Knowledge Wiki server running on http://localhost:${PORT}`);
  });
}

bootstrap().catch((err) => {
  console.error("Failed to bootstrap server application:", err);
});
